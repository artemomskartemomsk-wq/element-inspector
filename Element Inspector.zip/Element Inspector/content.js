console.log("Content script initialized at", new Date().toISOString());

let tooltip = null;
let fixedTooltip = null;
let isFixed = false;
let highlightBox = null;
let arrowLine = null;
let fixedArrowLine = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message received:", message);
  if (message.action === "toggleInspector") {
    if (message.isActive) {
      console.log("Enabling inspector");
      enableInspector();
    } else {
      console.log("Disabling inspector");
      disableInspector();
    }
    sendResponse({ status: "success" });
  }
});

function enableInspector() {
  isFixed = false;
  document.addEventListener("mousemove", onHover);
  document.addEventListener("click", onClick, true);
  console.log("Inspector enabled, listeners added");
}

function disableInspector() {
  console.log("Disabling inspector, cleaning up...");
  document.removeEventListener("mousemove", onHover);
  document.removeEventListener("click", onClick, true);

  [tooltip, fixedTooltip, highlightBox, arrowLine, fixedArrowLine].forEach((el) => {
    if (el) {
      el.remove();
      el = null;
    }
  });

  tooltip = null;
  fixedTooltip = null;
  highlightBox = null;
  arrowLine = null;
  fixedArrowLine = null;
  isFixed = false;
}

function onHover(e) {
  if (isFixed) return;

  const el = document.elementFromPoint(e.clientX, e.clientY);
  if (!el || el.classList.contains("inspector-tooltip") || el.classList.contains("inspector-highlight")) {
    console.log("Ignoring invalid or inspector element");
    return;
  }

  const rect = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);

  console.log("Hover on element:", el.tagName, "at", rect, "with styles:", {
    fontFamily: style.fontFamily,
    fontSize: style.fontSize,
    fontWeight: style.fontWeight,
    color: style.color,
    backgroundColor: style.backgroundColor
  });

  updateTooltip(el, rect, style, e.pageX, e.pageY);
  updateHighlight(rect);
  updateArrow(rect);
}

function updateTooltip(el, rect, style, x, y) {
  if (!el || !rect || !style) {
    console.warn("Invalid element, rect, or style, skipping tooltip update");
    return;
  }

  if (!tooltip) {
    tooltip = document.createElement("div");
    tooltip.className = "inspector-tooltip";
    document.body.appendChild(tooltip);
    console.log("Tooltip created");
  }

  const textColor = style.color === "rgba(0, 0, 0, 0)" ? "transparent" : style.color;
  const bgColor = style.backgroundColor === "rgba(0, 0, 0, 0)" ? "transparent" : style.backgroundColor;

  tooltip.innerHTML = `
    <span class="label">Размер элемента:</span> ${Math.round(rect.width)} × ${Math.round(rect.height)}\n
    <span class="label">Закругление:</span> ${style.borderRadius}\n
    <span class="label">Шрифт:</span> ${style.fontFamily}\n
    <span class="label">Размер шрифта:</span> ${style.fontSize}\n
    <span class="label">Жирность шрифта:</span> ${style.fontWeight}\n
    <span class="label">Цвет текста:</span> <span style="display: inline-block; width: 12px; height: 12px; background-color: ${textColor}; border: 1px solid #fff; vertical-align: middle; margin-left: 5px;"></span> ${style.color}\n
    <span class="label">Цвет фона:</span> <span style="display: inline-block; width: 12px; height: 12px; background-color: ${bgColor}; border: 1px solid #fff; vertical-align: middle; margin-left: 5px;"></span> ${style.backgroundColor}
  `;

  // Изначально устанавливаем позицию тултипа
  tooltip.style.top = `${y + 15}px`;
  tooltip.style.left = `${x + 15}px`;

  // Проверяем, выходит ли тултип за границы экрана
  const tooltipRect = tooltip.getBoundingClientRect();
  const offset = 15; // Отступ от курсора

  // Если тултип выходит за нижнюю границу, размещаем его выше курсора
  if (tooltipRect.bottom > window.innerHeight) {
    tooltip.style.top = `${y - tooltipRect.height - offset}px`;
    console.log("Tooltip moved above cursor due to bottom overflow");
  }

  // Если тултип выходит за правую границу, размещаем его слева от курсора
  if (tooltipRect.right > window.innerWidth) {
    tooltip.style.left = `${x - tooltipRect.width - offset}px`;
    console.log("Tooltip moved left of cursor due to right overflow");
  }

  // Если тултип уходит за верхнюю границу
  if (tooltipRect.top < 0) {
    tooltip.style.top = `${offset}px`;
    console.log("Tooltip moved to top edge due to top overflow");
  }

  // Если тултип уходит за левую границу
  if (tooltipRect.left < 0) {
    tooltip.style.left = `${offset}px`;
    console.log("Tooltip moved to left edge due to left overflow");
  }
}

function updateHighlight(rect) {
  if (!rect) {
    console.warn("Invalid rect, skipping highlight update");
    return;
  }

  if (!highlightBox) {
    highlightBox = document.createElement("div");
    highlightBox.className = "inspector-highlight";
    document.body.appendChild(highlightBox);
    console.log("Highlight box created");
  }

  Object.assign(highlightBox.style, {
    top: `${window.scrollY + rect.top}px`,
    left: `${window.scrollX + rect.left}px`,
    width: `${rect.width}px`,
    height: `${rect.height}px`,
    display: "block",
  });
}

function updateArrow(rect) {
  if (!tooltip || !rect) {
    console.warn("No tooltip or invalid rect, skipping arrow update");
    return;
  }

  if (!arrowLine) {
    arrowLine = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    arrowLine.setAttribute("class", "inspector-arrow");
    arrowLine.style.position = "absolute";
    arrowLine.style.pointerEvents = "none";
    arrowLine.style.overflow = "visible";

    arrowLine.innerHTML = `
      <defs>
        <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto-start-reverse">
          <polygon points="0 0, 10 3.5, 0 7" fill="#4caf50" />
        </marker>
      </defs>
      <line x1="0" y1="0" x2="0" y2="0" stroke="#4caf50" stroke-width="2" marker-end="url(#arrowhead)" />
    `;

    tooltip.appendChild(arrowLine);
    console.log("Arrow created");
  }

  const elCenterX = window.scrollX + rect.left + rect.width / 2;
  const elCenterY = window.scrollY + rect.top + rect.height / 2;

  const tooltipRect = tooltip.getBoundingClientRect();
  const tooltipAbsX = window.scrollX + tooltipRect.left;
  const tooltipAbsY = window.scrollY + tooltipRect.top;

  const x1 = tooltipRect.width / 2;
  const y1 = tooltipRect.height / 2;
  const x2 = elCenterX - tooltipAbsX;
  const y2 = elCenterY - tooltipAbsY;

  const left = Math.min(x1, x2);
  const top = Math.min(y1, y2);
  const width = Math.max(Math.abs(x2 - x1), 10);
  const height = Math.max(Math.abs(y2 - y1), 10);

  arrowLine.style.left = `${left}px`;
  arrowLine.style.top = `${top}px`;
  arrowLine.setAttribute("width", width);
  arrowLine.setAttribute("height", height);

  const line = arrowLine.querySelector("line");
  line.setAttribute("x1", x1 - left);
  line.setAttribute("y1", y1 - top);
  line.setAttribute("x2", x2 - left);
  line.setAttribute("y2", y2 - top);
}

function onClick(e) {
  if (!tooltip || isFixed) return;

  console.log("Element clicked, fixing tooltip");
  e.preventDefault();
  e.stopImmediatePropagation();

  isFixed = true;
  fixedTooltip = tooltip;
  tooltip = null;

  fixedTooltip.classList.add("fixed");

  // Проверяем и корректируем позицию fixedTooltip
  const tooltipRect = fixedTooltip.getBoundingClientRect();
  const offset = 15;
  if (tooltipRect.bottom > window.innerHeight) {
    fixedTooltip.style.top = `${window.innerHeight - tooltipRect.height - offset}px`;
    console.log("Fixed tooltip moved above due to bottom overflow");
  }
  if (tooltipRect.right > window.innerWidth) {
    fixedTooltip.style.left = `${window.innerWidth - tooltipRect.width - offset}px`;
    console.log("Fixed tooltip moved left due to right overflow");
  }
  if (tooltipRect.top < 0) {
    fixedTooltip.style.top = `${offset}px`;
    console.log("Fixed tooltip moved to top edge due to top overflow");
  }
  if (tooltipRect.left < 0) {
    fixedTooltip.style.left = `${offset}px`;
    console.log("Fixed tooltip moved to left edge due to left overflow");
  }

  const closeBtn = document.createElement("div");
  closeBtn.className = "inspector-close";
  closeBtn.textContent = "✖";
  closeBtn.onclick = () => {
    console.log("Closing fixed tooltip");
    fixedTooltip.remove();
    fixedTooltip = null;
    if (fixedArrowLine) {
      fixedArrowLine.remove();
      fixedArrowLine = null;
    }
    isFixed = false;
    enableInspector();
  };

  fixedTooltip.appendChild(closeBtn);

  document.removeEventListener("mousemove", onHover);
  document.removeEventListener("click", onClick, true);

  if (highlightBox) highlightBox.style.display = "none";

  if (arrowLine) {
    fixedArrowLine = arrowLine;
    arrowLine = null;
  }
}