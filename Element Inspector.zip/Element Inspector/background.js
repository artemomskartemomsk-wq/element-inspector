chrome.storage.local.get("isActive", (data) => {
  if (!data.isActive) {
    chrome.storage.local.set({ isActive: {} });
  }
});

chrome.action.onClicked.addListener((tab) => {
  if (tab.url.startsWith("chrome://") || tab.url.startsWith("about:")) {
    console.warn(`Cannot run on ${tab.url}`);
    chrome.action.setBadgeText({ text: "ERR", tabId: tab.id });
    chrome.action.setBadgeBackgroundColor({ color: "#FF0000", tabId: tab.id });
    setTimeout(() => chrome.action.setBadgeText({ text: "", tabId: tab.id }), 3000);
    return;
  }

  chrome.storage.local.get("isActive", (data) => {
    const isActive = data.isActive || {};
    console.log(`Icon clicked for tab ${tab.id}, isActive before:`, isActive[tab.id]);

    isActive[tab.id] = !isActive[tab.id] || false;
    chrome.storage.local.set({ isActive }, () => {
      console.log(`isActive after:`, isActive[tab.id]);

      chrome.action.setIcon({
        path: isActive[tab.id] ? "icons/icon-on.svg" : "icons/icon-off.svg",
        tabId: tab.id
      });

      chrome.tabs.sendMessage(tab.id, { action: "toggleInspector", isActive: isActive[tab.id] }, (response) => {
        if (chrome.runtime.lastError) {
          console.error(`Error sending message to tab ${tab.id}:`, chrome.runtime.lastError);
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content.js"]
          }, () => {
            if (chrome.runtime.lastError) {
              console.error(`Error injecting content.js:`, chrome.runtime.lastError);
            } else {
              console.log("Content script injected, retrying message");
              chrome.tabs.sendMessage(tab.id, { action: "toggleInspector", isActive: isActive[tab.id] });
            }
          });
        } else {
          console.log(`Message sent to tab ${tab.id}, isActive:`, isActive[tab.id]);
        }
      });
    });
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.get("isActive", (data) => {
    const isActive = data.isActive || {};
    delete isActive[tabId];
    chrome.storage.local.set({ isActive }, () => {
      console.log(`Tab ${tabId} closed, cleared isActive`);
    });
  });
});